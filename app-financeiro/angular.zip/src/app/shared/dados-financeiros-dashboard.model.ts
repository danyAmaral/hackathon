export class DadosFinanceirosDashboard{
    public ano:number;
    public mes:string;
    public valor:number;
}